<div class="alert alert-info">
    <strong>Version 3.0 released with Bootstrap 4.3.1, jQuery 3.3.1, Vue.js 2.6.10, Laravel 6.0.* with bug fixes.</strong>
</div><?php /**PATH E:\laragon\www\vue\resources\views/message.blade.php ENDPATH**/ ?>